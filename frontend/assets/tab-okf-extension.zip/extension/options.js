const input = document.getElementById("endpoint");
const ok = document.getElementById("ok");

chrome.storage.sync.get("endpoint").then(({ endpoint }) => {
  input.value = endpoint || "http://127.0.0.1:8765";
});

document.getElementById("save").addEventListener("click", async () => {
  await chrome.storage.sync.set({ endpoint: input.value.trim() || "http://127.0.0.1:8765" });
  ok.textContent = "saved ✓";
  setTimeout(() => (ok.textContent = ""), 1500);
});
