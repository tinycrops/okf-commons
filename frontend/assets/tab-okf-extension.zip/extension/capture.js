// Capture window (standalone popup window — survives tabbing away).
// The intent draft is autosaved to storage keyed by the target URL, so nothing is
// ever lost: if the window is closed before you bank, reopening it for the same page
// restores what you typed.

const $ = (id) => document.getElementById(id);

const params = new URLSearchParams(location.search);
const target = {
  tabId: Number(params.get("tabId")),
  url: params.get("url") || "",
  title: params.get("title") || "",
};
const draftKey = `draft:${target.url}`;

async function refreshBanked() {
  const today = new Date().toISOString().slice(0, 10);
  const { bankedDay, bankedCount } = await chrome.storage.local.get(["bankedDay", "bankedCount"]);
  $("banked").textContent = bankedDay === today ? bankedCount || 0 : 0;
}

let savedTimer = null;
function flashSaved() {
  const el = $("saved");
  el.textContent = "draft saved ✓";
  el.classList.add("show");
  clearTimeout(savedTimer);
  savedTimer = setTimeout(() => {
    el.textContent = "draft autosaved";
    el.classList.remove("show");
  }, 1200);
}

async function saveDraft(value) {
  if (value.trim()) {
    await chrome.storage.local.set({ [draftKey]: value });
  } else {
    await chrome.storage.local.remove(draftKey);
  }
  flashSaved();
}

function showError(msg) {
  const el = $("err");
  el.textContent = msg;
  el.style.display = "block";
  $("go").disabled = false;
  $("go").textContent = "Capture & Close ↵";
}

function showReward(count) {
  $("form-view").style.display = "none";
  $("reward-view").style.display = "block";
  $("reward-count").textContent = `${count} banked today.`;
  setTimeout(() => window.close(), 900);
}

async function submit(ev) {
  ev.preventDefault();
  $("err").style.display = "none";
  $("go").disabled = true;
  $("go").textContent = "Banking…";
  const intent = $("intent").value;
  const res = await chrome.runtime.sendMessage({ type: "capture", tabId: target.tabId, intent });
  if (res && res.ok) {
    await chrome.storage.local.remove(draftKey); // only clear the draft once it's safely banked
    showReward(res.count);
  } else {
    showError((res && res.error) || "Capture failed. Your draft is still saved.");
  }
}

async function init() {
  $("page-title").textContent = target.title || target.url;
  await refreshBanked();

  // Restore any draft for this page.
  const stored = await chrome.storage.local.get(draftKey);
  if (stored[draftKey]) $("intent").value = stored[draftKey];

  const ta = $("intent");
  // Autosave on every edit (input fires for typing, paste, cut).
  ta.addEventListener("input", () => saveDraft(ta.value));
  // Belt-and-braces: also save when focus leaves the field.
  ta.addEventListener("blur", () => saveDraft(ta.value));
  // Enter banks; Shift+Enter inserts a newline.
  ta.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("capture-form").requestSubmit(); }
  });

  $("capture-form").addEventListener("submit", submit);
  $("open-memory").addEventListener("click", async () => {
    const { endpoint } = await chrome.storage.sync.get("endpoint");
    const base = (endpoint || "http://127.0.0.1:8765").replace(/\/+$/, "");
    chrome.tabs.create({ url: `${base}/gallery` });
  });

  ta.focus();
  ta.selectionStart = ta.selectionEnd = ta.value.length;
}

init();
