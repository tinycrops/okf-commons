# Tab OKF — Chrome extension

Click the toolbar button (or press **Ctrl+Shift+S**) to **bank the current tab into
your OKF knowledge memory and close it**. The reason you kept the tab open is
captured, compressed with `gpt-5.4-mini` into Open Knowledge Format, and made
retrievable by your agent swarm.

The reward is the close, not the open: a badge counts how many tabs you've banked
today.

## The capture server (always-on)

The extension talks to a local server — nothing leaves your machine except the page
text sent to the model for compression.

The project and its OKF memory now live on the **internal NVMe** at `~/tab-okf`
(moved off the external video drive after a power-loss corruption). It runs as an
always-on systemd user service that survives logout and reboot:

```bash
systemctl --user status  tab-okf.service   # is it up?
systemctl --user restart tab-okf.service   # after editing tab_okf.py
journalctl  --user -u   tab-okf.service -f # live capture log
```

The unit is at `~/.config/systemd/user/tab-okf.service`; the API key lives in
`~/.config/tab-okf/env` (chmod 600). To run it by hand instead:

```bash
cd ~/tab-okf
export OPENAI_API_KEY=...            # omit + pass --no-openai for deterministic extraction
python3 tab_okf.py serve --out bundles/open-tabs
# -> http://127.0.0.1:8765   POST /capture   GET /search?q=   GET /recent
```

## Load the extension

1. Open `chrome://extensions`, enable **Developer mode**.
2. **Load unpacked** → select this `extension/` directory.
3. (Optional) pin the icon. Click ⚙ → **Options** to change the server endpoint.

## Use it

- **Click the icon** (or **Ctrl+Shift+E**) → a standalone capture window opens with an
  optional "why are you keeping this?" field → **Capture & Close** (Enter banks it,
  Shift+Enter for a newline).
  - The window is a real popup window, so it **stays open when you tab away** to grab
    reference material.
  - Your typing is **autosaved per page** as you go. If the window ever closes before
    you bank, reopening it for the same page restores your draft. The draft only clears
    once the page is safely banked.
- **Ctrl+Shift+S** → instant bank + close, no prompt (purpose is inferred).
- **Memory** button, or **click the "Banked" notification**, or visit
  `http://127.0.0.1:8765/gallery` → the live OKF memory gallery (newest first, with the
  "Why Kept" reason on each).

Shortcuts are editable at `chrome://extensions/shortcuts`.

## What an agent retrieves

```bash
curl 'http://127.0.0.1:8765/search?q=which%20plan%20should%20I%20buy'
```

Returns ranked OKF concepts weighted by **why the tab was kept** (`inferred_purpose`)
and **when it should resurface** (`retrieval_cues`) — not just page text. This is the
on-demand memory sector the swarm reads from.
