// Tab OKF — service worker.
// Orchestrates the reward loop: extract the live page, POST it to the local capture
// server, then close the tab. The visible reward is a growing "banked today" badge —
// accumulation you can feel, replacing the cheap hit of opening one more tab.

const DEFAULT_ENDPOINT = "http://127.0.0.1:8765";

async function getEndpoint() {
  const { endpoint } = await chrome.storage.sync.get("endpoint");
  return (endpoint || DEFAULT_ENDPOINT).replace(/\/+$/, "");
}

async function serverHealth(endpoint) {
  try {
    const response = await fetch(`${endpoint}/health`, { method: "GET", cache: "no-store" });
    if (!response.ok) return { ok: false, error: `Capture server returned ${response.status}` };
    const body = await response.json();
    return body && body.ok ? { ok: true, body } : { ok: false, error: "Capture server is not ready." };
  } catch (_) {
    return {
      ok: false,
      error: `Capture server is offline at ${endpoint}. Start it with: systemctl --user start tab-okf.service`,
    };
  }
}

// Injected into the page. Pull readable text the way a person reads it — the rendered
// DOM, not raw HTML — so JS-built and logged-in pages capture correctly.
function extractReadable() {
  const drop = "script,style,noscript,svg,canvas,nav,footer,aside,form,iframe,[aria-hidden='true']";
  const clone = document.body ? document.body.cloneNode(true) : null;
  if (clone) clone.querySelectorAll(drop).forEach((n) => n.remove());
  const text = (clone ? clone.innerText : document.body ? document.body.innerText : "") || "";
  const meta = (sel) => (document.querySelector(sel)?.getAttribute("content") || "").trim();
  const links = Array.from(document.querySelectorAll("a[href^='http']"))
    .map((a) => a.href)
    .filter((v, i, arr) => arr.indexOf(v) === i)
    .slice(0, 100);
  return {
    url: location.href,
    final_url: location.href,
    title: document.title || "",
    description: meta("meta[name='description']") || meta("meta[property='og:description']"),
    text: text.replace(/\n{3,}/g, "\n\n").slice(0, 60000),
    links,
  };
}

async function setBadge(tabId) {
  const today = new Date().toISOString().slice(0, 10);
  const store = await chrome.storage.local.get(["bankedDay", "bankedCount"]);
  let count = store.bankedDay === today ? (store.bankedCount || 0) + 1 : 1;
  await chrome.storage.local.set({ bankedDay: today, bankedCount: count });
  await chrome.action.setBadgeBackgroundColor({ color: "#176b63" });
  await chrome.action.setBadgeText({ text: String(count) });
  return count;
}

// Notifications tagged with this prefix open the memory gallery when clicked.
const BANK_NOTIF_PREFIX = "tab-okf-banked:";

async function notify(title, message) {
  try {
    await chrome.notifications.create(BANK_NOTIF_PREFIX + Date.now(), {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message,
    });
  } catch (_) { /* notifications optional */ }
}

// Click the "Banked into OKF memory" toast -> open the live memory gallery.
chrome.notifications.onClicked.addListener(async (notificationId) => {
  if (!notificationId.startsWith(BANK_NOTIF_PREFIX)) return;
  const endpoint = await getEndpoint();
  await chrome.tabs.create({ url: `${endpoint}/gallery` });
  chrome.notifications.clear(notificationId);
});

// The whole loop for one tab. Returns a result the caller (popup or command) can react to.
async function captureTab(tab, intent) {
  if (!tab || !tab.id || !/^https?:/.test(tab.url || "")) {
    return { ok: false, error: "This page can't be captured (only http/https tabs)." };
  }
  const endpoint = await getEndpoint();
  const health = await serverHealth(endpoint);
  if (!health.ok) return health;
  let payload;
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractReadable,
    });
    payload = res.result;
  } catch (e) {
    // Fall back to bare metadata; the server will fetch server-side if text is empty.
    payload = { url: tab.url, final_url: tab.url, title: tab.title || "", text: "", links: [] };
  }
  payload.intent = (intent || "").trim();
  payload.browser = "chrome";
  payload.profile = "extension";

  let response;
  try {
    response = await fetch(`${endpoint}/capture`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    return { ok: false, error: `Capture server unreachable at ${endpoint}. Start it with: tab_okf.py serve` };
  }
  if (!response.ok && response.status !== 202) {
    return { ok: false, error: `Server returned ${response.status}` };
  }
  const count = await setBadge(tab.id);
  // The trade is now safe: the page is queued into memory. Close the tab.
  try { await chrome.tabs.remove(tab.id); } catch (_) {}
  notify("Banked into OKF memory", `${payload.title || payload.url}\n${count} tab${count === 1 ? "" : "s"} banked today.`);
  return { ok: true, count, title: payload.title || payload.url };
}

// Open the capture UI as a standalone popup WINDOW (not an action popup). A real
// window does not close when you tab away to grab reference material — so your
// half-written intent survives switching focus.
async function openCaptureWindow(tab) {
  if (!tab || !/^https?:/.test(tab.url || "")) {
    notify("Can't capture this page", "Only http/https tabs can be banked.");
    return;
  }
  const params = new URLSearchParams({ tabId: String(tab.id), url: tab.url, title: tab.title || "" });
  await chrome.windows.create({
    url: chrome.runtime.getURL("capture.html") + "?" + params.toString(),
    type: "popup",
    width: 380,
    height: 320,
    focused: true,
  });
}

// Toolbar button (no default_popup, so this fires) + the open-capture shortcut.
chrome.action.onClicked.addListener((tab) => openCaptureWindow(tab));

// The capture window asks us to bank a SPECIFIC tab by id (the active tab has since
// changed to the capture window itself, so we must target by id, not "active").
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "capture") {
    (async () => {
      let tab = null;
      try {
        tab = msg.tabId ? await chrome.tabs.get(msg.tabId) : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
      } catch (_) {
        return sendResponse({ ok: false, error: "Target tab no longer exists." });
      }
      sendResponse(await captureTab(tab, msg.intent));
    })();
    return true; // async response
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (command === "open-capture") {
    await openCaptureWindow(tab);
  } else if (command === "capture-instant") {
    // Lowest-friction reward: bank + close with no prompt.
    await captureTab(tab, "");
  }
});
